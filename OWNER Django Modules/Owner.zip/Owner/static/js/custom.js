$(document).ready(function(){
     
    $(".dateinput").datepicker({changeYear: true,changeMonth: true});
 
 
});