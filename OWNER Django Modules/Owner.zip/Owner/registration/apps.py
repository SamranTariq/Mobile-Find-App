from django.apps import AppConfig


class RegistraionConfig(AppConfig):
    name = 'registraion'
