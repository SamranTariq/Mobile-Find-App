from django.shortcuts import render, redirect
import pyrebase
from pyfcm import FCMNotification
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import send_mail
from django.conf import settings

config = {
    'apiKey': "AIzaSyAbAic4HzDK-Y5ZdxJY-eWDvvf5iipZe8E",
    'authDomain': "owner-6ca6b.firebaseapp.com",
    'databaseURL': "https://owner-6ca6b.firebaseio.com",
    'projectId': "owner-6ca6b",
    'storageBucket': "owner-6ca6b.appspot.com",
    'messagingSenderId': "546281266274",
    'appId': "1:546281266274:web:8703ac00243435f5b1c53b",
    "serviceAccount": "/home/samran/django_project/projects/OWNER2/Owner/owner-6ca6b-firebase-adminsdk-mswn5-cc44f552fa.json"
}
firebase = pyrebase.initialize_app(config)

auth = firebase.auth()
database=firebase.database()
# Create your views here.
def forgetpassword(request):
   return render(request,'forgetpassword.html')

def register(request):
        return render(request,'registeration.html')
def confirmation(request):
        return render(request,'confirmation.html')
def login(request):
    if request.method=="POST":
        return redirect('dashboard')
    else:
        return render(request,'dashboard.html')
def contact(request):
    return render(request,'contactus.html')
def sendmail(request):
    email1=request.POST.get('email')
    try:
        auth.send_password_reset_email(email1)
    except:
        message="invalid Credentials"
        return render(request,'forgetpassword.html',{"ms":message})
    message1="Please Check your email and Reset Password"
    return render(request,'registeration.html',{"m":message1})
def dashboard(request):
    email=request.POST.get('email')
    passw=request.POST.get('pass')
    try:
        user=auth.sign_in_with_email_and_password(email,passw)
    except:
        messages.success(request,"Oops! Try Again")
        return render(request,'registeration.html')
    session_id = user['idToken']
    request.session['uid'] = str(session_id)
    print(user["localId"])
    a=user["localId"]
    global simple_variable
    simple_variable=a
    name = database.child('Users').child(a).child("Detail").child('name').get().val()
    davicename = database.child('Users').child(a).child("Detail").child('devicename').get().val()
    modelname = database.child('Users').child(a).child("Detail").child('modelname').get().val()
    image = database.child('Users').child(a).child("Images").child("imageuri").get().val()
    #image = "{% static 'images/user.png' %}"
    return render(request,'dashboard.html',{'n':name,'dn':davicename,'mn':modelname,'im':image})

def onmailsend(request):
  b=simple_variable
  name=request.POST.get('name')
  subject=request.POST.get('subject')
  email=request.POST.get('email')
  phone=request.POST.get('phone')
  message=request.POST.get('message')
  body="Name = "+name+"   "+"Sender_Email = "+email+"   "+"Sender_Phone_No = "+phone+"   "+"Complain :: "+message
  send_mail(subject,body,'iowner88@gmail.com',['iowner88@gmail.com'], fail_silently=False)
#  data = {"request": "sended"}
 # database.child('Users').child(b).child('email').child('status').set(data)
  return render(request, 'confirmation.html')
  

def forcelockmobile(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    #users = database.child("Users").child(.getUid())
    #devicetoken=users.child('tokenvalue').get().val()
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
    #message_title = "Uber update"
    #message_body = "great match!"
    #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
    "Nick" : "Mario",
    "body" : "great match!",
    "Room" : "PortugalVSDenmark"
    }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
    #mes="Mobile Locked:)"
    return HttpResponse("")
    #return HttpResponse("hlo")
    #return render(request,'new.html',{'ms':mes})
    #return HttpResponse('success')

def ownershowinfo(request):
     push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
     b=simple_variable
     tokenval = database.child('Users').child(b).child('Token').get().val()
     registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
     data_message = {
      "Nick" : "Mario",
      "body" : "sms oh!",
      "Room" : "PortugalVSDenmark"
  }
     result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
     return HttpResponse("")
   # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
     #mes="Notification Send:)"
     #return render(request,'new.html',{'ms':mes})
     

def smsunlock(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")

    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval#message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "unlock mobile!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
    

def onnoone(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "Stop unlock!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
   # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
    #mes="Mobile Lock Protected:)"
    #return render(request,'new.html',{'ms':mes})

def onscreenunlock(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
     #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "Screen Lock!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
   # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
    #mes="Screen Lock Protected:)"
    #return render(request,'new.html',{'ms':mes})

def onresetdefault(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "Default Reset!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
   # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
    #mes="Reset All Locked Function:)"
    #return render(request,'new.html',{'ms':mes})

def onringmobile(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
     #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "Ring Mobile!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
   # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
    #mes="Mobile Ringing Start:)"
    #return render(request,'new.html',{'ms':mes})

def onstopringing(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "Stop Ring!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
   # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
    #mes="Ringing Mobile Stop:)"
    #return render(request,'new.html',{'ms':mes})

def location(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "Location Send!",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
  # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
  #mes="Location Tracking Start:)"
  #latitude = database.child('Users').child(b).child('Location').child("latitude").get().val()
  #longitude = database.child('Users').child(b).child('Location').child("longitude").get().val()
  mes="Location Tracking Sart:)"
  return render(request,'new.html',{'ms':mes})


def onstoplocation(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "Stop Location!",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
  # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
  #mes="Location Tracking Start:)"
  #latitude = database.child('Users').child(b).child('Location').child("latitude").get().val()
  #longitude = database.child('Users').child(b).child('Location').child("longitude").get().val()
  mes="Location Tracking Stop:)"
  return render(request,'new.html',{'ms':mes})

def SignUpView(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")

  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval#message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "unlock mobile!",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
   # result = push_service.notify_single_device(registration_id=registration_id, message_body=message_body, data_message=data_message)
  mes="CHECK PASSWORD ON MOBILE:)"
  return HttpResponse("")  
def checkajax(request):
    image = "/static/images/user.png"
    return render(request,'checkajax.html',{'im':image})
def onsoon(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "Location Send!",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
  return HttpResponse(b)
#battery
def oncheckbattery(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "Battery Check!",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
  return HttpResponse(b)

def onconnectedwifi(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "Connected Wifi!",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
  return HttpResponse(b)

def onrangewifi(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "Range Wifi!",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
  return HttpResponse(b)

def onimei(request):
  b=simple_variable
  return HttpResponse(b)

def onfactoryreset(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
     #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "Stop Factory Reset!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
def onhourfactoryreset(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
     #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "HourStop Factory Reset!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
def onhourscreenunlock(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
     #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "HourStop Screen Lock!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
def onhourlocksafe(request):
    push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
    b=simple_variable
    tokenval = database.child('Users').child(b).child('Token').get().val()
    registration_id = tokenval
     #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
    data_message = {
     "Nick" : "Mario",
     "body" : "HourStop Mobile Lock!",
     "Room" : "PortugalVSDenmark"
   }
    result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
    return HttpResponse("")
def onmobileconnection(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "internet connection!",
    "Room" : "PortugalVSDenmark"
  }
  kwargs = {
        "content_available": True,
        'extra_kwargs': {"priority": "high", "mutable_content": True, 'notification': data_message },
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message, **kwargs)
  return HttpResponse(b)

#Locked App Start
def onlockedapp(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "Locked Application's",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
  return HttpResponse("")
#End Locked Process
#Locked App Start
def onunlockedapp(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "UNLocked Them",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
  return HttpResponse("")
#End Locked Process

#Start Chnge name process
def onchangename(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  return HttpResponse(b)
#end change name process
#Start Chnge model name process
def onmobilemodelchangename(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  return HttpResponse(b)
#end change model name process
#Start Chnge devicenamechangename process
def ondevicenamechangename(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  return HttpResponse(b)
#end change devicenamechangename process
def onlivedemoconn(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  tokenval = database.child('Users').child(b).child('Token').get().val()
  registration_id = tokenval
   #message_title = "Uber update"
   #message_body = "great match!"
 #  result = push_service.notify_single_device(registration_id=registration_id, message_title=message_title, message_body=message_body)
  data_message = {
    "Nick" : "Mario",
    "body" : "liveonload!",
    "Room" : "PortugalVSDenmark"
  }
  result = push_service.single_device_data_message(registration_id=registration_id, data_message=data_message)
  return HttpResponse(b)
#USer Delete
def ondeleteuser(request):
  push_service = FCMNotification(api_key="AAAAfzDmnGI:APA91bGzhGnXu8F_EQBLMUi8BbuOReOr7Ao7iWJUdC-28700KxjfOOS0skn-C-i02gKiumSKwbHpGndKBWajAaWDfQl-mt5QsVFtEIM2yb-vkR0ZYPD07QqkAvxf-0BEzSygKB2TXYkC")
  b=simple_variable
  #auth.delete_user(b)
  return HttpResponse(b)
def onprivacy(request):
  return render(request,'Privacy.html')
def onterms(request):
  return render(request,"terms.html")